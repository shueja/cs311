
int main(int argc, char* argv[]) {
	cout << "Hello World" << endl;
}
